<?php
// =============================================
//  api/auth.php
//  Actions : login | register | logout | me
// =============================================
require_once __DIR__ . '/../config/database.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── Connexion ─────────────────────────────
    case 'login':
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';

        if (!$email || !$pass) {
            jsonResponse(['success' => false, 'error' => 'Veuillez remplir tous les champs.']);
        }

        $pdo = getDB();

        // Vérifier admin
        $stmt = $pdo->prepare("SELECT * FROM administrateur WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($pass, $admin['password'])) {
            $_SESSION['user_id']   = $admin['id'];
            $_SESSION['user_name'] = $admin['nom'];
            $_SESSION['email']     = $admin['email'];
            $_SESSION['role']      = 'admin';
            jsonResponse(['success' => true, 'role' => 'admin', 'name' => $admin['nom']]);
        }

        // Vérifier client
        $stmt = $pdo->prepare("SELECT * FROM client WHERE email = ?");
        $stmt->execute([$email]);
        $client = $stmt->fetch();

        if ($client && password_verify($pass, $client['password'])) {
            if ($client['bloque']) {
                jsonResponse(['success' => false, 'error' => "ACCÈS NON AUTORISÉ — Votre compte a été suspendu par l'administrateur."]);
            }
            $_SESSION['user_id']   = $client['id'];
            $_SESSION['user_name'] = $client['prenom'] . ' ' . $client['nom'];
            $_SESSION['email']     = $client['email'];
            $_SESSION['role']      = 'client';
            jsonResponse(['success' => true, 'role' => 'client', 'name' => $client['prenom']]);
        }

        jsonResponse(['success' => false, 'error' => 'ACCÈS NON AUTORISÉ — Email ou mot de passe incorrect.']);
        break;

    // ── Inscription ───────────────────────────
    case 'register':
        $prenom = trim($_POST['prenom'] ?? '');
        $nom    = trim($_POST['nom']    ?? '');
        $email  = trim($_POST['email']  ?? '');
        $phone  = trim($_POST['phone']  ?? '');
        $ville  = trim($_POST['ville']  ?? '');
        $pass   = $_POST['password']    ?? '';

        if (!$prenom || !$nom || !$email || !$pass) {
            jsonResponse(['success' => false, 'error' => 'Veuillez remplir tous les champs obligatoires.']);
        }
        if (strlen($pass) < 6) {
            jsonResponse(['success' => false, 'error' => 'Le mot de passe doit contenir au moins 6 caractères.']);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'error' => 'Adresse email invalide.']);
        }

        $pdo = getDB();

        // Email déjà utilisé ?
        $stmt = $pdo->prepare("SELECT id FROM client WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'Un compte existe déjà avec cet email.']);
        }

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            "INSERT INTO client (prenom, nom, email, telephone, ville, password) VALUES (?,?,?,?,?,?)"
        );
        $stmt->execute([$prenom, $nom, $email, $phone, $ville, $hash]);
        $newId = $pdo->lastInsertId();

        $_SESSION['user_id']   = $newId;
        $_SESSION['user_name'] = "$prenom $nom";
        $_SESSION['email']     = $email;
        $_SESSION['role']      = 'client';

        jsonResponse(['success' => true, 'role' => 'client', 'name' => $prenom]);
        break;

    // ── Déconnexion ───────────────────────────
    case 'logout':
        session_destroy();
        jsonResponse(['success' => true]);
        break;

    // ── Infos session courante ─────────────────
    case 'me':
        if (!isLogged()) {
            jsonResponse(['logged' => false]);
        }
        jsonResponse([
            'logged' => true,
            'role'   => $_SESSION['role'],
            'name'   => $_SESSION['user_name'],
            'email'  => $_SESSION['email'],
        ]);
        break;

    default:
        jsonResponse(['success' => false, 'error' => 'Action inconnue.'], 400);
}
