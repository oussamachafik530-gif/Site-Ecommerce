<?php
// =============================================
//  index.php — Point d'entrée principal
// =============================================
require_once __DIR__ . '/config/database.php';
include __DIR__ . '/includes/header.php';
?>

<!-- ══ BANNIÈRE COMPTE BLOQUÉ ══════════════════ -->
<?php
$isBlocked = false;
if (isClient()) {
    $pdo  = getDB();
    $stmt = $pdo->prepare("SELECT bloque FROM client WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch();
    $isBlocked = $row && (bool)$row['bloque'];
}
?>
<div class="blocked-banner <?= $isBlocked ? 'show' : '' ?>" id="blockedBanner">
  <i class="fas fa-ban"></i>
  <strong>Votre compte est suspendu.</strong>&nbsp;Vous ne pouvez plus passer commande. Contactez-nous pour plus d'informations.
</div>

<!-- ══════════════════════════════════════════════
     PAGE : HOME
══════════════════════════════════════════════ -->
<div id="page-home" class="page active">
  <div class="hero">
    <div class="hero-badge"><i class="fas fa-bolt"></i> Leader en Informatique au Maroc</div>
    <h1>Le Meilleur du Tech,<br><em>Livré Partout</em></h1>
    <p>Matériels informatiques premium, consoles gaming, composants PC et smartphones. Garantie originale. Livraison sécurisée dans toutes les villes du Maroc.</p>
    <div class="hero-btns">
      <button class="btn btn-primary" onclick="scrollToProducts()">
        <i class="fas fa-shopping-bag" style="margin-right:8px"></i>Explorer les produits
      </button>
      <button class="btn btn-outline" onclick="showPage('contact')">
        <i class="fas fa-envelope" style="margin-right:8px"></i>Nous contacter
      </button>
    </div>
  </div>

  <!-- Stats -->
  <?php
  $pdo       = getDB();
  $nbProd    = $pdo->query("SELECT COUNT(*) FROM materiel")->fetchColumn();
  $nbClients = $pdo->query("SELECT COUNT(*) FROM client")->fetchColumn();
  ?>
  <div class="stats-bar">
    <div class="stat-item">
      <div class="stat-num" id="st-products"><?= (int)$nbProd ?></div>
      <div class="stat-label">Produits disponibles</div>
    </div>
    <div class="stat-item"><div class="stat-num">500+</div><div class="stat-label">Clients satisfaits</div></div>
    <div class="stat-item"><div class="stat-num">100%</div><div class="stat-label">Garantie originale</div></div>
    <div class="stat-item"><div class="stat-num">24h</div><div class="stat-label">Livraison express</div></div>
  </div>

  <!-- Catégories -->
  <div class="section-title" id="shop-anchor">Catégories <span>Filtrer par type</span></div>
  <div class="cat-scroll">
    <div class="cat-chip active" onclick="filterCat('')"        id="cat-all">    <i class="fas fa-th-large"></i>  Tout voir</div>
    <div class="cat-chip"       onclick="filterCat('Laptop')"   id="cat-Laptop"> <i class="fas fa-laptop"></i>     Laptops</div>
    <div class="cat-chip"       onclick="filterCat('Phone')"    id="cat-Phone">  <i class="fas fa-mobile-alt"></i> Smartphones</div>
    <div class="cat-chip"       onclick="filterCat('GPU')"      id="cat-GPU">    <i class="fas fa-microchip"></i>  Composants</div>
    <div class="cat-chip"       onclick="filterCat('Console')"  id="cat-Console"><i class="fas fa-gamepad"></i>    Consoles</div>
    <div class="cat-chip"       onclick="filterCat('Monitor')"  id="cat-Monitor"><i class="fas fa-desktop"></i>   Moniteurs</div>
  </div>

  <div id="productsGrid" class="products-grid"></div>
</div>

<!-- ══════════════════════════════════════════════
     PAGE : DÉTAIL PRODUIT
══════════════════════════════════════════════ -->
<div id="page-detail" class="page">
  <div class="detail-wrap">
    <div class="back-btn" onclick="showPage('home')">
      <i class="fas fa-arrow-left"></i> Retour à la boutique
    </div>
    <div id="detailContent"></div>
  </div>
</div>

<!-- ══════════════════════════════════════════════
     PAGE : AUTHENTIFICATION
══════════════════════════════════════════════ -->
<div id="page-auth" class="page">
  <div class="auth-wrap">
    <div class="auth-card">
      <h2>Bienvenue</h2>
      <p>Connectez-vous pour accéder à votre compte</p>

      <div class="auth-tabs">
        <div class="auth-tab active" onclick="switchAuthTab('login')">Connexion</div>
        <div class="auth-tab"       onclick="switchAuthTab('register')">Inscription</div>
      </div>

      <div class="auth-err" id="authErr"></div>

      <!-- Formulaire Connexion -->
      <div id="formLogin">
        <div class="form-group">
          <label class="form-label">Email</label>
          <input class="form-input" type="email" id="loginEmail" placeholder="votre@email.com">
        </div>
        <div class="form-group">
          <label class="form-label">Mot de passe</label>
          <input class="form-input" type="password" id="loginPass" placeholder="••••••••">
        </div>
        <button class="btn btn-primary" style="width:100%;margin-top:8px;" onclick="handleLogin()">
          Se connecter
        </button>
        <p style="text-align:center;margin-top:14px;font-size:0.8rem;color:var(--muted);">
          Admin : admin@marocpc.ma / admin1234
        </p>
      </div>

      <!-- Formulaire Inscription -->
      <div id="formRegister" style="display:none;">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Prénom</label>
            <input class="form-input" type="text" id="regFirst" placeholder="Prénom">
          </div>
          <div class="form-group">
            <label class="form-label">Nom</label>
            <input class="form-input" type="text" id="regLast" placeholder="Nom">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input class="form-input" type="email" id="regEmail" placeholder="votre@email.com">
        </div>
        <div class="form-group">
          <label class="form-label">Téléphone</label>
          <input class="form-input" type="tel" id="regPhone" placeholder="+212 6XXXXXXXX">
        </div>
        <div class="form-group">
          <label class="form-label">Ville</label>
          <input class="form-input" type="text" id="regCity" placeholder="Casablanca">
        </div>
        <div class="form-group">
          <label class="form-label">Mot de passe</label>
          <input class="form-input" type="password" id="regPass" placeholder="••••••••">
        </div>
        <button class="btn btn-primary" style="width:100%;margin-top:8px;" onclick="handleRegister()">
          Créer mon compte
        </button>
      </div>
    </div>
  </div>
</div>

<!-- ══════════════════════════════════════════════
     PAGE : PANIER
══════════════════════════════════════════════ -->
<div id="page-cart" class="page">
  <div style="padding:40px 5% 20px;">
    <h1 style="font-family:var(--font-head);font-size:1.8rem;font-weight:800;margin-bottom:8px;">Mon Panier</h1>
    <p style="color:var(--muted);font-size:0.88rem;">Simulation de commande et validation</p>
  </div>
  <div id="cartContent"></div>
</div>

<!-- ══════════════════════════════════════════════
     PAGE : CONFIRMATION COMMANDE
══════════════════════════════════════════════ -->
<div id="page-order" class="page">
  <div style="padding:60px 5%;">
    <div id="orderConfirmContent"></div>
  </div>
</div>

<!-- ══════════════════════════════════════════════
     PAGE : ADMIN
══════════════════════════════════════════════ -->
<div id="page-admin" class="page">
  <div class="admin-wrap">
    <div class="admin-header">
      <h1><i class="fas fa-shield-alt" style="color:var(--accent);margin-right:12px;"></i>Panneau d'Administration</h1>
      <div class="admin-tabs">
        <div class="admin-tab active" onclick="switchAdminTab('dashboard',this)">Dashboard</div>
        <div class="admin-tab"       onclick="switchAdminTab('products',this)">Produits</div>
        <div class="admin-tab"       onclick="switchAdminTab('add',this)">Ajouter</div>
        <div class="admin-tab"       onclick="switchAdminTab('orders',this)">Commandes</div>
        <div class="admin-tab"       onclick="switchAdminTab('clients',this)">Clients</div>
      </div>
    </div>

    <!-- DASHBOARD -->
    <div id="admin-dashboard" class="admin-content active">
      <div class="admin-stats">
        <div class="admin-stat">
          <div class="admin-stat-icon" style="background:rgba(108,99,255,0.12);color:var(--accent);"><i class="fas fa-box"></i></div>
          <div class="admin-stat-num" id="adm-total-prod">—</div>
          <div class="admin-stat-label">Total produits</div>
        </div>
        <div class="admin-stat">
          <div class="admin-stat-icon" style="background:rgba(20,184,166,0.12);color:var(--teal);"><i class="fas fa-shopping-cart"></i></div>
          <div class="admin-stat-num" id="adm-total-orders">—</div>
          <div class="admin-stat-label">Total commandes</div>
        </div>
        <div class="admin-stat">
          <div class="admin-stat-icon" style="background:rgba(108,99,255,0.15);color:var(--accent2);"><i class="fas fa-bell"></i></div>
          <div class="admin-stat-num" id="adm-new-orders">—</div>
          <div class="admin-stat-label">Nouvelles commandes</div>
        </div>
        <div class="admin-stat">
          <div class="admin-stat-icon" style="background:rgba(245,158,11,0.12);color:var(--gold);"><i class="fas fa-users"></i></div>
          <div class="admin-stat-num" id="adm-total-clients">—</div>
          <div class="admin-stat-label">Clients inscrits</div>
        </div>
        <div class="admin-stat">
          <div class="admin-stat-icon" style="background:rgba(239,68,68,0.12);color:var(--red);"><i class="fas fa-exclamation-triangle"></i></div>
          <div class="admin-stat-num" id="adm-low-stock">—</div>
          <div class="admin-stat-label">Stock critique</div>
        </div>
        <div class="admin-stat">
          <div class="admin-stat-icon" style="background:rgba(249,115,22,0.12);color:var(--orange);"><i class="fas fa-ban"></i></div>
          <div class="admin-stat-num" id="adm-blocked">—</div>
          <div class="admin-stat-label">Clients bloqués</div>
        </div>
      </div>

      <div class="section-title" style="padding:0;margin-bottom:16px;">Produits à Réapprovisionner</div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Produit</th><th>Catégorie</th><th>Stock</th><th>Prix achat</th><th>Prix vente</th><th>Statut</th></tr></thead>
          <tbody id="lowStockBody"></tbody>
        </table>
      </div>
    </div>

    <!-- PRODUITS -->
    <div id="admin-products" class="admin-content">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>ID</th><th>Produit</th><th>Catégorie</th><th>Prix achat</th><th>Prix vente</th><th>Stock</th><th>Statut</th><th>Action</th></tr></thead>
          <tbody id="adminProdBody"></tbody>
        </table>
      </div>
    </div>

    <!-- AJOUTER PRODUIT -->
    <div id="admin-add" class="admin-content">
      <div class="add-form">
        <h3><i class="fas fa-plus-circle" style="color:var(--accent);margin-right:8px;"></i>Ajouter un Matériel</h3>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Nom du produit *</label>
            <input class="form-input" type="text" id="addName" placeholder="Ex: Dell XPS 15">
          </div>
          <div class="form-group">
            <label class="form-label">Catégorie *</label>
            <select class="form-input" id="addCat">
              <option value="Laptop">Laptop</option>
              <option value="Phone">Smartphone</option>
              <option value="GPU">Composant</option>
              <option value="Console">Console</option>
              <option value="Monitor">Moniteur</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Prix d'achat (DH) *</label>
            <input class="form-input" type="number" id="addBuyPrice" placeholder="0" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Prix de vente (DH) *</label>
            <input class="form-input" type="number" id="addSellPrice" placeholder="0" min="0">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Quantité en stock *</label>
            <input class="form-input" type="number" id="addQty" value="1" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Caractéristiques</label>
            <input class="form-input" type="text" id="addSpecs" placeholder="Ex: i7-12700H, 16GB RAM">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Image produit (fichier)</label>
          <input class="form-input" type="file" id="addImg" accept="image/*" onchange="previewImg()">
        </div>
        <div class="form-group">
          <label class="form-label">— ou URL image</label>
          <input class="form-input" type="url" id="addImgUrl" placeholder="https://...">
        </div>
        <div class="img-preview-wrap"><img id="imgPreview" class="img-preview"></div>
        <div class="form-group" style="margin-top:16px;">
          <label class="form-label">Description</label>
          <textarea class="form-input" id="addDesc" rows="3" placeholder="Description du produit..." style="resize:vertical;"></textarea>
        </div>
        <button class="btn btn-primary" style="margin-top:16px;padding:14px 32px;" onclick="adminAddProduct()">
          <i class="fas fa-database" style="margin-right:8px;"></i>Enregistrer dans la base
        </button>
      </div>
    </div>

    <!-- COMMANDES -->
    <div id="admin-orders" class="admin-content">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
        <div class="orders-subtabs">
          <div class="orders-subtab active" id="stab-new" onclick="switchOrdersTab('new')">
            <i class="fas fa-bell"></i> Nouvelles <span class="cnt" id="cnt-new">0</span>
          </div>
          <div class="orders-subtab" id="stab-old" onclick="switchOrdersTab('old')">
            <i class="fas fa-history"></i> Anciennes <span class="cnt" id="cnt-old">0</span>
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <select class="form-input" id="filterOrderProd"   style="max-width:200px;" onchange="renderAdminOrders()">
            <option value="">Tous les produits</option>
          </select>
          <select class="form-input" id="filterOrderStatus" style="max-width:180px;" onchange="renderAdminOrders()">
            <option value="">Tous les statuts</option>
            <option value="validée">Validée</option>
            <option value="rupture">Rupture de stock</option>
          </select>
        </div>
      </div>

      <!-- Nouvelles -->
      <div id="section-new-orders">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="font-family:var(--font-head);font-weight:700;display:flex;align-items:center;gap:8px;">
            <span class="dot-new"></span> Nouvelles commandes — à traiter
          </div>
          <button onclick="toutTraiter()" style="background:rgba(108,99,255,0.12);color:var(--accent2);border:1px solid rgba(108,99,255,0.25);padding:7px 14px;border-radius:8px;cursor:pointer;font-size:0.8rem;font-weight:600;">
            <i class="fas fa-check-double" style="margin-right:6px;"></i>Tout marquer traité
          </button>
        </div>
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>N°</th><th>Client</th><th>Produits</th><th>Total</th><th>Date</th><th>Statut</th><th>Action</th></tr></thead>
            <tbody id="bodyNewOrders"></tbody>
          </table>
        </div>
      </div>

      <!-- Anciennes -->
      <div id="section-old-orders" style="display:none;margin-top:24px;">
        <div style="font-family:var(--font-head);font-weight:700;display:flex;align-items:center;gap:8px;margin-bottom:12px;">
          <i class="fas fa-history" style="color:var(--muted);"></i> Anciennes commandes — traitées
        </div>
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>N°</th><th>Client</th><th>Produits</th><th>Total</th><th>Date</th><th>Statut</th></tr></thead>
            <tbody id="bodyOldOrders"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- CLIENTS -->
    <div id="admin-clients" class="admin-content">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap;">
        <select class="form-input" id="filterClientStatut" style="max-width:200px;" onchange="renderAdminClients()">
          <option value="">Tous les clients</option>
          <option value="actif">Actifs seulement</option>
          <option value="bloqué">Bloqués seulement</option>
        </select>
        <span style="font-size:0.82rem;color:var(--muted);">
          <i class="fas fa-info-circle" style="margin-right:4px;"></i>
          Un client bloqué ne peut plus se connecter ni commander
        </span>
      </div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Nom</th><th>Email</th><th>Téléphone</th><th>Ville</th><th>Commandes</th><th>Statut</th><th>Actions</th></tr></thead>
          <tbody id="adminClientsBody"></tbody>
        </table>
      </div>
    </div>

  </div><!-- /.admin-wrap -->
</div><!-- /#page-admin -->

<!-- ══════════════════════════════════════════════
     PAGE : CONTACT
══════════════════════════════════════════════ -->
<div id="page-contact" class="page">
  <div class="contact-wrap">
    <div class="contact-card">
      <h2><i class="fas fa-envelope" style="color:var(--accent);margin-right:10px;"></i>Contactez-nous</h2>
      <p>Notre équipe répond dans les 24h. Vous pouvez aussi nous appeler directement.</p>
      <div class="form-group">
        <label class="form-label">Votre nom</label>
        <input class="form-input" type="text" id="ctxName" placeholder="Votre nom complet">
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input class="form-input" type="email" id="ctxEmail" placeholder="votre@email.com">
      </div>
      <div class="form-group">
        <label class="form-label">Sujet</label>
        <select class="form-input" id="ctxSubject">
          <option>Demande d'information produit</option>
          <option>Suivi de commande</option>
          <option>Service après-vente</option>
          <option>Autre</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Message</label>
        <textarea class="form-input" id="ctxMsg" rows="5" placeholder="Votre message..." style="resize:vertical;"></textarea>
      </div>
      <button class="btn btn-primary" style="margin-top:8px;padding:13px 28px;" onclick="sendContact()">
        <i class="fas fa-paper-plane" style="margin-right:8px;"></i>Envoyer le message
      </button>
      <div style="margin-top:28px;padding-top:24px;border-top:1px solid var(--border);display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:0.85rem;color:var(--muted);">
        <div><i class="fas fa-map-marker-alt" style="color:var(--accent);margin-right:8px;"></i>Bd Hassan II, Casablanca</div>
        <div><i class="fas fa-phone" style="color:var(--teal);margin-right:8px;"></i>+212 719477070</div>
        <div><i class="fas fa-envelope" style="color:var(--gold);margin-right:8px;"></i>admin@marocpc.ma</div>
        <div><i class="fas fa-clock" style="color:var(--muted);margin-right:8px;"></i>Lun–Sam : 9h–19h</div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
