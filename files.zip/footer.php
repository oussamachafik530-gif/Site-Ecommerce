<!-- ══ FAB (admin) ══════════════════════════════ -->
<?php if (isAdmin()): ?>
<button class="fab" id="fabBtn" onclick="showPage('admin')"><i class="fas fa-plus"></i></button>
<?php endif; ?>

<!-- ══ TOAST ════════════════════════════════════ -->
<div class="toast" id="toast">
  <span class="toast-icon" id="toastIcon"></span>
  <span id="toastMsg"></span>
</div>

<!-- ══ MODAL : Supprimer produit ════════════════ -->
<div class="modal-overlay" id="deleteModal">
  <div class="modal">
    <h3>Confirmer la suppression</h3>
    <p>Cette action est irréversible. Le produit sera définitivement supprimé de la base de données.</p>
    <div class="modal-actions">
      <button class="btn-ghost"  onclick="closeModal('deleteModal')">Annuler</button>
      <button class="btn-danger" onclick="confirmDelete()">Supprimer</button>
    </div>
  </div>
</div>

<!-- ══ MODAL : Bloquer client ═══════════════════ -->
<div class="modal-overlay" id="blockModal">
  <div class="modal">
    <h3><i class="fas fa-ban" style="color:var(--orange);margin-right:8px;"></i>Bloquer ce client ?</h3>
    <p id="blockModalTxt">Le client ne pourra plus se connecter ni passer commande.</p>
    <div class="modal-actions">
      <button class="btn-ghost" onclick="closeModal('blockModal')">Annuler</button>
      <button class="btn-warn"  onclick="confirmBloquer()"><i class="fas fa-ban" style="margin-right:6px;"></i>Bloquer</button>
    </div>
  </div>
</div>

<!-- ══ MODAL : Supprimer client ═════════════════ -->
<div class="modal-overlay" id="deleteClientModal">
  <div class="modal">
    <h3><i class="fas fa-user-times" style="color:var(--red);margin-right:8px;"></i>Supprimer ce client ?</h3>
    <p id="deleteClientTxt">Toutes les données de ce client seront supprimées définitivement.</p>
    <div class="modal-actions">
      <button class="btn-ghost"  onclick="closeModal('deleteClientModal')">Annuler</button>
      <button class="btn-danger" onclick="confirmSupprimerClient()"><i class="fas fa-trash" style="margin-right:6px;"></i>Supprimer</button>
    </div>
  </div>
</div>

<!-- ══ SCRIPTS ═══════════════════════════════════ -->
<script src="assets/js/app.js"></script>
<script>
  // Initialisation au chargement
  initApp();
</script>
</body>
</html>
