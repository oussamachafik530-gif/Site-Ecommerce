<?php
// =============================================
//  api/products.php
//  Actions : list | detail | add | delete | upload_image
// =============================================
require_once __DIR__ . '/../config/database.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── Liste des produits ────────────────────
    case 'list':
        $pdo = getDB();
        $cat = $_GET['cat'] ?? '';
        if ($cat) {
            $stmt = $pdo->prepare("SELECT * FROM materiel WHERE categorie = ? ORDER BY id DESC");
            $stmt->execute([$cat]);
        } else {
            $stmt = $pdo->query("SELECT * FROM materiel ORDER BY id DESC");
        }
        $products = $stmt->fetchAll();

        // Masquer prix_achat aux clients non admin
        if (!isAdmin()) {
            foreach ($products as &$p) unset($p['prix_achat']);
        }

        jsonResponse(['success' => true, 'products' => $products]);
        break;

    // ── Détail d'un produit ───────────────────
    case 'detail':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID manquant.'], 400);

        $pdo  = getDB();
        $stmt = $pdo->prepare("SELECT * FROM materiel WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();

        if (!$product) jsonResponse(['success' => false, 'error' => 'Produit introuvable.'], 404);

        if (!isAdmin()) unset($product['prix_achat']);

        jsonResponse(['success' => true, 'product' => $product]);
        break;

    // ── Ajouter un produit (admin) ────────────
    case 'add':
        requireAdmin();

        $nom        = trim($_POST['nom']        ?? '');
        $categorie  = trim($_POST['categorie']  ?? 'Laptop');
        $prix_achat = (float)($_POST['prix_achat']  ?? 0);
        $prix_vente = (float)($_POST['prix_vente']  ?? 0);
        $quantite   = (int)($_POST['quantite']      ?? 0);
        $specs      = trim($_POST['specs']      ?? '');
        $description= trim($_POST['description']?? '');

        if (!$nom || !$prix_vente) {
            jsonResponse(['success' => false, 'error' => 'Nom et prix de vente obligatoires.']);
        }

        // Gestion image uploadée
        $imagePath = null;
        if (!empty($_FILES['image']['tmp_name'])) {
            $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','webp','gif'];
            if (!in_array($ext, $allowed)) {
                jsonResponse(['success' => false, 'error' => 'Format image non autorisé.']);
            }
            $filename  = uniqid('prod_') . '.' . $ext;
            $uploadDir = __DIR__ . '/../assets/images/products/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $filename);
            $imagePath = 'assets/images/products/' . $filename;
        } else {
            $imagePath = trim($_POST['image_url'] ?? '');
        }

        $pdo  = getDB();
        $stmt = $pdo->prepare(
            "INSERT INTO materiel (nom, categorie, prix_achat, prix_vente, quantite, specs, description, image)
             VALUES (?,?,?,?,?,?,?,?)"
        );
        $stmt->execute([$nom, $categorie, $prix_achat, $prix_vente, $quantite, $specs, $description, $imagePath]);

        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId(), 'message' => 'Produit ajouté avec succès ✓']);
        break;

    // ── Supprimer un produit (admin) ──────────
    case 'delete':
        requireAdmin();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID manquant.'], 400);

        $pdo  = getDB();
        $stmt = $pdo->prepare("DELETE FROM materiel WHERE id = ?");
        $stmt->execute([$id]);

        jsonResponse(['success' => true, 'message' => 'Produit supprimé.']);
        break;

    default:
        jsonResponse(['success' => false, 'error' => 'Action inconnue.'], 400);
}
