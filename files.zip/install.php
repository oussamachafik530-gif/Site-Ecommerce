<?php
// =============================================
//  install.php — Script d'installation automatique
//  Exécuter UNE SEULE FOIS : http://localhost/marocpc/install.php
//  SUPPRIMER ce fichier après installation !
// =============================================

define('DB_HOST',    'localhost');
define('DB_NAME',    'marocpc');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_CHARSET', 'utf8mb4');

$steps = [];
$ok    = true;

try {
    // ── 1. Connexion sans base ────────────────
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";charset=".DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $steps[] = ['ok', 'Connexion MySQL établie'];

    // ── 2. Créer la base ─────────────────────
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `".DB_NAME."` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `".DB_NAME."`");
    $steps[] = ['ok', 'Base de données "'.DB_NAME.'" créée / vérifiée'];

    // ── 3. Créer les tables ───────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS administrateur (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        nom        VARCHAR(100)  NOT NULL,
        email      VARCHAR(150)  NOT NULL UNIQUE,
        password   VARCHAR(255)  NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS materiel (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        nom         VARCHAR(200) NOT NULL,
        categorie   ENUM('Laptop','Phone','GPU','Console','Monitor') DEFAULT 'Laptop',
        prix_achat  DECIMAL(10,2) NOT NULL DEFAULT 0,
        prix_vente  DECIMAL(10,2) NOT NULL DEFAULT 0,
        quantite    INT NOT NULL DEFAULT 0,
        specs       TEXT,
        description TEXT,
        image       VARCHAR(500) DEFAULT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS client (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        prenom     VARCHAR(100) NOT NULL,
        nom        VARCHAR(100) NOT NULL,
        email      VARCHAR(150) NOT NULL UNIQUE,
        telephone  VARCHAR(30),
        ville      VARCHAR(100),
        password   VARCHAR(255) NOT NULL,
        bloque     TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS commande_client (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        client_id  INT NOT NULL,
        sous_total DECIMAL(10,2) NOT NULL DEFAULT 0,
        livraison  DECIMAL(10,2) NOT NULL DEFAULT 0,
        total      DECIMAL(10,2) NOT NULL DEFAULT 0,
        statut     ENUM('validée','rupture','annulée') NOT NULL DEFAULT 'validée',
        traitee    TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES client(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS commande_detail (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        commande_id   INT NOT NULL,
        materiel_id   INT NOT NULL,
        nom_produit   VARCHAR(200) NOT NULL,
        prix_unitaire DECIMAL(10,2) NOT NULL,
        quantite      INT NOT NULL DEFAULT 1,
        total_ligne   DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (commande_id) REFERENCES commande_client(id) ON DELETE CASCADE,
        FOREIGN KEY (materiel_id) REFERENCES materiel(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");

    $steps[] = ['ok', 'Toutes les tables créées'];

    // ── 4. Insérer l'admin ────────────────────
    $checkAdmin = $pdo->query("SELECT COUNT(*) FROM administrateur")->fetchColumn();
    if ($checkAdmin == 0) {
        $hash = password_hash('admin1234', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO administrateur (nom, email, password) VALUES (?,?,?)");
        $stmt->execute(['Administrateur', 'admin@marocpc.ma', $hash]);
        $steps[] = ['ok', 'Administrateur créé (admin@marocpc.ma / admin1234)'];
    } else {
        $steps[] = ['info', 'Administrateur déjà présent — non modifié'];
    }

    // ── 5. Insérer les produits de démo ───────
    $checkProd = $pdo->query("SELECT COUNT(*) FROM materiel")->fetchColumn();
    if ($checkProd == 0) {
        $stmt = $pdo->prepare(
            "INSERT INTO materiel (nom, categorie, prix_achat, prix_vente, quantite, specs, description, image)
             VALUES (?,?,?,?,?,?,?,?)"
        );
        $produits = [
            ['PlayStation 5 Pro',       'Console', 7000,  8500,  5, '4K 120fps, SSD 1TB, DualSense',                 'La dernière console de Sony avec des performances inégalées.',               'https://gmedia.playstation.com/is/image/SIEPDC/ps5-product-thumbnail-01-en-14sep21?$facebook$'],
            ['ASUS ROG Strix G16',      'Laptop',  11000, 14500, 3, 'i9-13980HX, RTX 4070, 32GB, 1TB NVMe',          'Laptop gaming ultime pour les performances maximales.',                      'https://dlcdnwebimgs.asus.com/gain/9F88BA73-1B9E-4F8E-B9EF-9EA618C0A2A3/w717/h525'],
            ['Samsung Galaxy S24 Ultra','Phone',   8500,  11000, 8, 'Snapdragon 8 Gen 3, 12GB RAM, 200MP, 5000mAh',  'Smartphone flagship avec stylet intégré et caméra révolutionnaire.',       'https://images.samsung.com/is/image/samsung/p6pim/levant/sm-s928bzkcmea/gallery/levant-galaxy-s24-ultra-s928-sm-s928bzkcmea-536858985?$730_730_PNG$'],
            ['RTX 4090 Founders Ed.',   'GPU',     14000, 17500, 2, '16384 CUDA Cores, 24GB GDDR6X, 450W TDP',       'La carte graphique la plus puissante de NVIDIA pour la génération actuelle.','https://www.nvidia.com/content/dam/en-zz/Solutions/geforce/ada/rtx-4090/geforce-ada-4090-og-1200x630.jpg'],
            ['LG UltraWide 34" WQHD',  'Monitor', 4500,  6200,  6, '34", 3440x1440, 165Hz, 1ms, HDR600, USB-C',     'Expérience immersive cinématographique avec taux de rafraîchissement gaming.','https://www.lg.com/us/images/monitors/md08003696/gallery/LG-34GP950G-B-D-01.jpg'],
            ['iPhone 15 Pro Max',       'Phone',   12000, 15500, 4, 'A17 Pro, 48MP, ProRes Video, USB-C, Titanium',  "Le flagship d'Apple avec puce A17 Pro et châssis en titane.",              'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-15-pro-finish-select-202309-6-7inch-naturaltitanium?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1692845702708'],
            ['Xbox Series X',           'Console', 4200,  5800,  1, 'Zen 2 8c, RDNA 2 12 TFLOPS, 1TB NVMe, 8K',    'La console Microsoft pour jouer à vos titres favoris en 4K.',               'https://news.xbox.com/en-us/wp-content/uploads/sites/2/2020/03/XboxSeriesX_FrontSide.jpg'],
        ];
        foreach ($produits as $p) $stmt->execute($p);
        $steps[] = ['ok', count($produits) . ' produits de démo insérés'];
    } else {
        $steps[] = ['info', 'Produits déjà présents — non modifiés'];
    }

} catch (PDOException $e) {
    $steps[] = ['error', 'Erreur : ' . $e->getMessage()];
    $ok = false;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Installation — Maroc PC</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: 'Segoe UI', sans-serif; background: #0a0a0f; color: #f1f0ff; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:40px 20px; }
    .card { background: #16161f; border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; padding: 40px; max-width: 600px; width: 100%; }
    h1 { font-size: 1.8rem; font-weight: 800; margin-bottom: 8px; }
    h1 span { color: #6c63ff; }
    .sub { color: #8882aa; font-size: 0.9rem; margin-bottom: 32px; }
    .step { display:flex; align-items:flex-start; gap:12px; padding:12px 0; border-bottom:1px solid rgba(255,255,255,0.06); }
    .step:last-child { border-bottom:none; }
    .icon-ok    { color: #22c55e; font-size: 1.1rem; margin-top:1px; }
    .icon-info  { color: #a78bfa; font-size: 1.1rem; margin-top:1px; }
    .icon-error { color: #ef4444; font-size: 1.1rem; margin-top:1px; }
    .step-msg { font-size: 0.9rem; line-height: 1.5; }
    .result { margin-top: 28px; padding: 20px; border-radius: 12px; text-align:center; }
    .result.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
    .result.error   { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
    .result h2 { font-size: 1.2rem; font-weight: 700; margin-bottom: 8px; }
    .result p { font-size: 0.85rem; color: #8882aa; margin-bottom: 16px; }
    .btn { display:inline-block; background: #6c63ff; color: #fff; padding: 12px 28px; border-radius: 10px; text-decoration:none; font-weight:600; font-size:0.9rem; transition:0.2s; }
    .btn:hover { background: #a78bfa; }
    .warn { background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); color: #f59e0b; padding: 12px 16px; border-radius: 8px; font-size: 0.82rem; margin-top: 16px; }
  </style>
</head>
<body>
<div class="card">
  <h1>MAROC<span>PC</span></h1>
  <p class="sub">Script d'installation automatique</p>

  <?php foreach ($steps as [$type, $msg]): ?>
  <div class="step">
    <span class="icon-<?= $type ?>">
      <?= $type === 'ok' ? '✅' : ($type === 'info' ? 'ℹ️' : '❌') ?>
    </span>
    <span class="step-msg"><?= htmlspecialchars($msg) ?></span>
  </div>
  <?php endforeach; ?>

  <?php if ($ok): ?>
  <div class="result success">
    <h2>✅ Installation réussie !</h2>
    <p>Votre base de données est prête. Vous pouvez maintenant utiliser le site.</p>
    <a href="index.php" class="btn">🚀 Accéder au site</a>
    <div class="warn" style="margin-top:16px;text-align:left;">
      ⚠️ <strong>Important :</strong> Supprimez le fichier <code>install.php</code> de votre serveur pour des raisons de sécurité !
    </div>
  </div>
  <?php else: ?>
  <div class="result error">
    <h2>❌ Erreur d'installation</h2>
    <p>Vérifiez vos paramètres dans <code>config/database.php</code> et réessayez.</p>
  </div>
  <?php endif; ?>
</div>
</body>
</html>
