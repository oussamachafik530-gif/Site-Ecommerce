<?php
// =============================================
//  includes/header.php
//  Balises <head> + navbar
// =============================================
require_once __DIR__ . '/../config/database.php';

$userLogged  = isLogged();
$userIsAdmin = isAdmin();
$userName    = $_SESSION['user_name'] ?? '';
$firstWord   = $userName ? explode(' ', $userName)[0] : 'Connexion';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maroc PC — Premium Tech Store</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- ══ NAVBAR ══════════════════════════════════ -->
<nav class="navbar">
  <div class="logo" onclick="showPage('home')">
    <div class="logo-dot"></div>
    MAROC<span>PC</span>
  </div>
  <div class="nav-links">
    <button class="nav-btn active" id="nb-home"    onclick="showPage('home')">
      <i class="fas fa-store"></i><span>Boutique</span>
    </button>
    <button class="nav-btn" id="nb-contact" onclick="showPage('contact')">
      <i class="fas fa-envelope"></i><span>Contact</span>
    </button>
    <button class="nav-btn" id="nb-auth" onclick="<?= $userLogged ? 'handleLogout()' : "showPage('auth')" ?>">
      <i class="fas fa-user"></i>
      <span id="navUserLabel"><?= h($firstWord) ?></span>
    </button>
    <button class="nav-btn" id="nb-cart" onclick="showPage('cart')">
      <i class="fas fa-shopping-cart"></i><span>Panier</span>
      <div class="cart-badge" id="cartBadge" style="display:none;">0</div>
    </button>
    <?php if ($userIsAdmin): ?>
    <button class="nav-btn" id="nb-admin" onclick="showPage('admin')">
      <i class="fas fa-shield-alt"></i><span>Admin</span>
    </button>
    <?php endif; ?>
  </div>
</nav>

<!-- Variable PHP → JS pour l'état initial -->
<script>
  const PHP_SESSION = {
    logged:  <?= json_encode($userLogged)  ?>,
    isAdmin: <?= json_encode($userIsAdmin) ?>,
    name:    <?= json_encode($userName)    ?>,
    email:   <?= json_encode($_SESSION['email'] ?? '') ?>,
  };
</script>
