// =============================================
//  assets/js/app.js — Maroc PC
//  Toute la logique front-end (fetch → API PHP)
// =============================================

/* ════════════════════════════════════════════
   ÉTAT GLOBAL
════════════════════════════════════════════ */
let cart        = JSON.parse(localStorage.getItem('marocpc_cart') || '[]');
let currentCat  = '';
let ordersTab   = 'new';
let pendingDeleteId    = null;
let pendingClientId    = null;
let pendingClientEmail = null;

/* ════════════════════════════════════════════
   INITIALISATION
════════════════════════════════════════════ */
function initApp() {
  updateCartBadge();
  updateNavFromSession();
  renderProducts();

  // Fermer modals Echap / clic extérieur
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape')
      ['deleteModal','blockModal','deleteClientModal'].forEach(id => {
        if (document.getElementById(id)?.classList.contains('open')) closeModal(id);
      });
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
      if (e.target === this) closeModal(this.id);
    });
  });
}

/* ════════════════════════════════════════════
   NAVIGATION
════════════════════════════════════════════ */
function showPage(id) {
  // Garder admin réservé
  if (id === 'admin' && !PHP_SESSION.isAdmin) {
    showPage('auth');
    toast('Accès réservé aux administrateurs', 'error');
    return;
  }

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + id)?.classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('nb-' + id)?.classList.add('active');

  if (id === 'home')  renderProducts();
  if (id === 'cart')  renderCart();
  if (id === 'admin') renderAdmin();
  window.scrollTo(0, 0);
}

function scrollToProducts() {
  document.getElementById('shop-anchor')?.scrollIntoView({ behavior: 'smooth' });
}

function updateNavFromSession() {
  const label = PHP_SESSION.logged
    ? (PHP_SESSION.name.split(' ')[0] || 'Compte')
    : 'Connexion';
  const el = document.getElementById('navUserLabel');
  if (el) el.textContent = label;
}

/* ════════════════════════════════════════════
   TOAST
════════════════════════════════════════════ */
function toast(msg, type = 'success') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warn: '⚠️' };
  document.getElementById('toastIcon').textContent = icons[type] || '✅';
  document.getElementById('toastMsg').textContent  = msg;
  const t = document.getElementById('toast');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}

/* ════════════════════════════════════════════
   MODALS
════════════════════════════════════════════ */
function openDeleteModal(e, id) {
  if (e) e.stopPropagation();
  pendingDeleteId = id;
  document.getElementById('deleteModal').classList.add('open');
}

function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
  if (id === 'deleteModal')       pendingDeleteId    = null;
  if (id === 'blockModal')        pendingClientId    = null;
  if (id === 'deleteClientModal') pendingClientId    = null;
}

/* ════════════════════════════════════════════
   PRODUITS
════════════════════════════════════════════ */
function filterCat(cat) {
  currentCat = cat;
  document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
  document.getElementById(cat ? 'cat-' + cat : 'cat-all')?.classList.add('active');
  renderProducts();
}

async function renderProducts() {
  const grid = document.getElementById('productsGrid');
  if (!grid) return;
  grid.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Chargement...</p></div>';

  const url = currentCat
    ? `api/products.php?action=list&cat=${encodeURIComponent(currentCat)}`
    : 'api/products.php?action=list';

  try {
    const res  = await fetch(url);
    const data = await res.json();
    if (!data.success) { grid.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><p>Erreur chargement</p></div>'; return; }

    const products = data.products;
    if (!products.length) {
      grid.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><p>Aucun produit trouvé</p></div>';
      return;
    }

    const catLabels = { Laptop:'Laptop', Phone:'Smartphone', GPU:'Composant', Console:'Console', Monitor:'Moniteur' };
    const isAdmin   = PHP_SESSION.isAdmin;

    grid.innerHTML = products.map(p => {
      const stockBadge = p.quantite == 0
        ? `<div class="p-badge badge-out">Rupture</div>`
        : p.quantite <= 2
          ? `<div class="p-badge badge-low">Dernier(s) : ${p.quantite}</div>`
          : `<div class="p-badge badge-stock">En stock : ${p.quantite}</div>`;

      const imgSrc = p.image || 'assets/images/no-image.svg';

      return `
        <div class="p-card" onclick="viewDetail(${p.id})">
          <div class="p-img-wrap">
            ${stockBadge}
            <img src="${imgSrc}" alt="${escHtml(p.nom)}" onerror="this.src='assets/images/no-image.svg'">
          </div>
          <div class="p-body">
            <div class="p-cat">${catLabels[p.categorie] || p.categorie}</div>
            <div class="p-name">${escHtml(p.nom)}</div>
            <div class="p-price">${fmtDH(p.prix_vente)}</div>
            ${isAdmin && p.prix_achat
              ? `<div class="p-price-buy">Achat : ${fmtDH(p.prix_achat)} | Marge : ${marge(p.prix_achat, p.prix_vente)}%</div>`
              : ''}
            <div class="p-actions">
              ${p.quantite > 0
                ? `<button class="btn-cart" onclick="addToCart(event,${p.id},'${escHtml(p.nom)}',${p.prix_vente},'${imgSrc}')"><i class="fas fa-cart-plus" style="margin-right:6px;"></i>Ajouter</button>`
                : `<button class="btn-cart" style="background:var(--muted);cursor:not-allowed;" disabled>Rupture de stock</button>`}
              ${isAdmin ? `<button class="btn-del-card" onclick="openDeleteModal(event,${p.id})"><i class="fas fa-trash"></i></button>` : ''}
            </div>
          </div>
        </div>`;
    }).join('');

    // Mettre à jour le compteur dans les stats
    const stEl = document.getElementById('st-products');
    if (stEl) stEl.textContent = products.length;

  } catch (err) {
    grid.innerHTML = '<div class="empty-state"><i class="fas fa-wifi"></i><p>Erreur réseau</p></div>';
  }
}

async function viewDetail(id) {
  try {
    const res  = await fetch(`api/products.php?action=detail&id=${id}`);
    const data = await res.json();
    if (!data.success) { toast('Produit introuvable', 'error'); return; }

    const p = data.product;
    const catLabels = { Laptop:'Laptop', Phone:'Smartphone', GPU:'Composant', Console:'Console', Monitor:'Moniteur' };
    const imgSrc    = p.image || 'assets/images/no-image.svg';

    const stockStatus = p.quantite == 0
      ? `<span style="color:var(--red)">Rupture de stock</span>`
      : p.quantite <= 2
        ? `<span style="color:var(--gold)">Stock limité (${p.quantite} restant${p.quantite > 1 ? 's' : ''})</span>`
        : `<span style="color:var(--green)">En stock (${p.quantite} disponibles)</span>`;

    const waMsg = encodeURIComponent(`Bonjour, je suis intéressé par : ${p.nom} - ${fmtDH(p.prix_vente)}`);

    document.getElementById('detailContent').innerHTML = `
      <div class="detail-grid">
        <div class="detail-img-wrap">
          <img src="${imgSrc}" alt="${escHtml(p.nom)}" onerror="this.src='assets/images/no-image.svg'">
        </div>
        <div class="detail-info">
          <div class="detail-cat-badge">${catLabels[p.categorie] || p.categorie}</div>
          <h1>${escHtml(p.nom)}</h1>
          <div class="detail-price">${fmtDH(p.prix_vente)}</div>
          ${PHP_SESSION.isAdmin && p.prix_achat
            ? `<div class="detail-price-buy">Prix d'achat : ${fmtDH(p.prix_achat)} — Marge : ${marge(p.prix_achat, p.prix_vente)}%</div>`
            : ''}
          <div class="detail-divider"></div>
          <div class="detail-spec"><span class="detail-spec-label">Disponibilité</span><span class="detail-spec-val">${stockStatus}</span></div>
          <div class="detail-spec"><span class="detail-spec-label">Catégorie</span><span class="detail-spec-val">${catLabels[p.categorie] || p.categorie}</span></div>
          ${p.specs ? `<div class="detail-spec"><span class="detail-spec-label">Caractéristiques</span><span class="detail-spec-val" style="font-size:0.82rem;text-align:right;max-width:55%;">${escHtml(p.specs)}</span></div>` : ''}
          ${p.description ? `<p class="detail-desc">${escHtml(p.description)}</p>` : ''}
          <div class="detail-btns">
            ${p.quantite > 0
              ? `<button class="btn-cart" style="padding:14px;font-size:0.92rem;" onclick="addToCart(null,${p.id},'${escHtml(p.nom)}',${p.prix_vente},'${imgSrc}');showPage('cart')"><i class="fas fa-shopping-cart" style="margin-right:8px;"></i>Ajouter au panier</button>`
              : `<button class="btn-cart" style="padding:14px;background:var(--muted);cursor:not-allowed;" disabled>Rupture de stock</button>`}
            <button class="btn-wa" onclick="window.open('https://wa.me/212719477070?text=${waMsg}')">
              <i class="fab fa-whatsapp"></i>Commander sur WhatsApp
            </button>
          </div>
        </div>
      </div>`;

    showPage('detail');
  } catch { toast('Erreur chargement produit', 'error'); }
}

/* ════════════════════════════════════════════
   PANIER (localStorage)
════════════════════════════════════════════ */
function addToCart(e, id, nom, prix, img) {
  if (e) e.stopPropagation();
  if (!PHP_SESSION.logged) { toast('Connectez-vous pour ajouter au panier', 'warn'); showPage('auth'); return; }

  const existing = cart.find(x => x.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ id, nom, prix, img, qty: 1 });
  }
  saveCart();
  toast(`${nom} ajouté au panier ✓`);
}

function changeQty(id, delta) {
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(x => x.id !== id);
  saveCart();
  renderCart();
}

function removeFromCart(id) {
  cart = cart.filter(x => x.id !== id);
  saveCart();
  renderCart();
}

function saveCart() {
  localStorage.setItem('marocpc_cart', JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  const badge = document.getElementById('cartBadge');
  if (!badge) return;
  badge.style.display = total > 0 ? 'flex' : 'none';
  badge.textContent   = total;
}

function renderCart() {
  const wrap = document.getElementById('cartContent');
  if (!wrap) return;

  if (!cart.length) {
    wrap.innerHTML = `
      <div class="empty-state" style="padding:100px 20px;">
        <i class="fas fa-shopping-cart"></i>
        <p>Votre panier est vide</p><br>
        <button class="btn btn-primary" onclick="showPage('home')">Continuer mes achats</button>
      </div>`;
    return;
  }

  const subtotal = cart.reduce((s, i) => s + i.prix * i.qty, 0);
  const delivery = subtotal > 10000 ? 0 : 79;
  const total    = subtotal + delivery;

  const items = cart.map(ci => `
    <div class="cart-item">
      <div class="cart-item-img"><img src="${ci.img || 'assets/images/no-image.svg'}" alt="${escHtml(ci.nom)}"></div>
      <div class="cart-item-info">
        <div class="cart-item-name">${escHtml(ci.nom)}</div>
        <div class="cart-item-price">${fmtDH(ci.prix * ci.qty)}</div>
        <div class="cart-qty">
          <button class="qty-btn" onclick="changeQty(${ci.id},-1)"><i class="fas fa-minus"></i></button>
          <span class="qty-num">${ci.qty}</span>
          <button class="qty-btn" onclick="changeQty(${ci.id},1)"><i class="fas fa-plus"></i></button>
          <span style="font-size:0.78rem;color:var(--muted);">× ${fmtDH(ci.prix)}</span>
        </div>
      </div>
      <button class="btn-remove" onclick="removeFromCart(${ci.id})"><i class="fas fa-times"></i></button>
    </div>`).join('');

  wrap.innerHTML = `
    <div class="cart-wrap">
      <div>
        <div class="cart-items">${items}</div>
        <button class="btn-outline" style="margin-top:16px;padding:10px 20px;font-size:0.85rem;"
          onclick="cart=[];saveCart();renderCart();">
          <i class="fas fa-trash" style="margin-right:6px;"></i>Vider le panier
        </button>
      </div>
      <div class="cart-summary">
        <h3>Simulation de commande</h3>
        <div class="summary-row"><span style="color:var(--muted)">Sous-total</span><span>${fmtDH(subtotal)}</span></div>
        <div class="summary-row">
          <span style="color:var(--muted)">Livraison</span>
          <span style="color:${delivery === 0 ? 'var(--green)' : 'inherit'}">${delivery === 0 ? 'Gratuite' : fmtDH(delivery)}</span>
        </div>
        ${delivery === 0
          ? '<div style="font-size:0.75rem;color:var(--green);margin:-8px 0 8px;text-align:right;">✓ Commande ≥ 10 000 DH</div>'
          : '<div style="font-size:0.75rem;color:var(--muted);margin:-8px 0 8px;text-align:right;">Livraison gratuite dès 10 000 DH</div>'}
        <div class="summary-row" style="border-bottom:none;padding-top:16px;">
          <span>Total TTC</span><span class="summary-total">${fmtDH(total)}</span>
        </div>
        ${cart.map(ci => `<div style="font-size:0.75rem;color:var(--muted);padding:2px 0;">${escHtml(ci.nom)} ×${ci.qty}</div>`).join('')}
        <button class="btn btn-primary" style="width:100%;margin-top:20px;padding:14px;" onclick="validateOrder()">
          <i class="fas fa-check-circle" style="margin-right:8px;"></i>Valider la commande
        </button>
        <button class="btn-wa" style="margin-top:10px;" onclick="orderViaWhatsApp()">
          <i class="fab fa-whatsapp"></i>Commander via WhatsApp
        </button>
      </div>
    </div>`;
}

/* ════════════════════════════════════════════
   COMMANDE
════════════════════════════════════════════ */
async function validateOrder() {
  if (!PHP_SESSION.logged) { toast('Connectez-vous pour passer commande', 'warn'); showPage('auth'); return; }
  if (!cart.length) { toast('Votre panier est vide', 'warn'); return; }

  const fd = new FormData();
  fd.append('action', 'validate');
  fd.append('cart',   JSON.stringify(cart.map(i => ({ id: i.id, qty: i.qty }))));

  try {
    const res  = await fetch('api/orders.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (!data.success) { toast(data.error, 'error'); return; }

    // Vider le panier
    cart = [];
    saveCart();

    // Afficher confirmation
    document.getElementById('orderConfirmContent').innerHTML = `
      <div class="order-card">
        <div class="check-icon"><i class="fas fa-check"></i></div>
        <h2 style="font-family:var(--font-head);text-align:center;margin-bottom:8px;">Commande Validée !</h2>
        <p style="color:var(--muted);text-align:center;margin-bottom:24px;">
          Merci <strong>${escHtml(data.client_name)}</strong>, votre commande a bien été enregistrée.
        </p>
        <div style="border-top:1px solid var(--border);padding-top:20px;">
          <div style="font-weight:700;margin-bottom:12px;font-size:0.9rem;text-transform:uppercase;color:var(--muted);">Détail</div>
          ${data.items.map(i => `
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:0.9rem;">
              <span>${escHtml(i.nom)} <span style="color:var(--muted);">×${i.qty}</span></span>
              <span style="font-weight:600;">${fmtDH(i.total)}</span>
            </div>`).join('')}
          <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:0.88rem;color:var(--muted);">
            <span>Livraison</span><span>${data.livraison == 0 ? 'Gratuite' : fmtDH(data.livraison)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding:16px 0 0;font-family:var(--font-head);font-size:1.4rem;font-weight:800;border-top:1px solid var(--border);margin-top:8px;">
            <span>Total facturé</span><span style="color:var(--teal);">${fmtDH(data.total)}</span>
          </div>
        </div>
        <button class="btn btn-primary" style="width:100%;margin-top:24px;" onclick="showPage('home')">
          <i class="fas fa-store" style="margin-right:8px;"></i>Retour à la boutique
        </button>
      </div>`;
    showPage('order');
  } catch { toast('Erreur réseau lors de la commande', 'error'); }
}

function orderViaWhatsApp() {
  const items = cart.map(i => `${i.nom} x${i.qty}`).join(', ');
  const total = cart.reduce((s, i) => s + i.prix * i.qty, 0);
  window.open(`https://wa.me/212719477070?text=Bonjour, je souhaite commander : ${encodeURIComponent(items)} | Total : ${fmtDH(total)}`);
}

/* ════════════════════════════════════════════
   AUTH
════════════════════════════════════════════ */
function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach((t, i) =>
    t.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'))
  );
  document.getElementById('formLogin').style.display    = tab === 'login'    ? 'block' : 'none';
  document.getElementById('formRegister').style.display = tab === 'register' ? 'block' : 'none';
  document.getElementById('authErr').classList.remove('show');
}

function showAuthErr(msg) {
  const el = document.getElementById('authErr');
  el.textContent = '⚠️ ' + msg;
  el.classList.add('show');
}

async function handleLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const pass  = document.getElementById('loginPass').value;
  if (!email || !pass) { showAuthErr('Veuillez remplir tous les champs.'); return; }

  const fd = new FormData();
  fd.append('action',   'login');
  fd.append('email',    email);
  fd.append('password', pass);

  try {
    const res  = await fetch('api/auth.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (!data.success) { showAuthErr(data.error); return; }

    // Mettre à jour PHP_SESSION côté JS
    PHP_SESSION.logged  = true;
    PHP_SESSION.isAdmin = data.role === 'admin';
    PHP_SESSION.name    = data.name;

    document.getElementById('navUserLabel').textContent = data.name.split(' ')[0];

    // Afficher/masquer bouton admin
    const nbAdmin = document.getElementById('nb-admin');
    if (nbAdmin) nbAdmin.style.display = PHP_SESSION.isAdmin ? 'flex' : 'none';
    const fab = document.getElementById('fabBtn');
    if (fab) fab.style.display = PHP_SESSION.isAdmin ? 'flex' : 'none';

    toast(`Bienvenue, ${data.name.split(' ')[0]} !`);
    showPage(data.role === 'admin' ? 'admin' : 'home');
  } catch { showAuthErr('Erreur réseau. Réessayez.'); }
}

async function handleRegister() {
  const prenom = document.getElementById('regFirst').value.trim();
  const nom    = document.getElementById('regLast').value.trim();
  const email  = document.getElementById('regEmail').value.trim();
  const phone  = document.getElementById('regPhone').value.trim();
  const ville  = document.getElementById('regCity').value.trim();
  const pass   = document.getElementById('regPass').value;

  if (!prenom || !nom || !email || !pass) { showAuthErr('Veuillez remplir tous les champs obligatoires.'); return; }

  const fd = new FormData();
  fd.append('action',   'register');
  fd.append('prenom',   prenom);
  fd.append('nom',      nom);
  fd.append('email',    email);
  fd.append('phone',    phone);
  fd.append('ville',    ville);
  fd.append('password', pass);

  try {
    const res  = await fetch('api/auth.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (!data.success) { showAuthErr(data.error); return; }

    PHP_SESSION.logged  = true;
    PHP_SESSION.isAdmin = false;
    PHP_SESSION.name    = `${prenom} ${nom}`;
    document.getElementById('navUserLabel').textContent = prenom;

    toast('Compte créé avec succès !');
    showPage('home');
  } catch { showAuthErr('Erreur réseau. Réessayez.'); }
}

async function handleLogout() {
  await fetch('api/auth.php', {
    method: 'POST',
    body: new URLSearchParams({ action: 'logout' }),
  });
  PHP_SESSION.logged  = false;
  PHP_SESSION.isAdmin = false;
  PHP_SESSION.name    = '';
  cart = [];
  saveCart();
  document.getElementById('navUserLabel').textContent = 'Connexion';
  const nbAdmin = document.getElementById('nb-admin');
  if (nbAdmin) nbAdmin.style.display = 'none';
  const fab = document.getElementById('fabBtn');
  if (fab) fab.style.display = 'none';

  toast('Vous êtes déconnecté', 'info');
  location.reload(); // recharge pour reset PHP_SESSION
}

/* ════════════════════════════════════════════
   ADMIN
════════════════════════════════════════════ */
function switchAdminTab(tab, el) {
  document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.admin-content').forEach(c => c.classList.remove('active'));
  el?.classList.add('active');
  document.getElementById('admin-' + tab)?.classList.add('active');

  if (tab === 'dashboard') renderAdminDashboard();
  if (tab === 'products')  renderAdminProducts();
  if (tab === 'orders')    renderAdminOrders();
  if (tab === 'clients')   renderAdminClients();
}

async function renderAdmin() {
  renderAdminDashboard();
  renderAdminProducts();
  renderAdminOrders();
  renderAdminClients();
  loadProductFilterOptions();
}

/* ── Dashboard ── */
async function renderAdminDashboard() {
  try {
    const res  = await fetch('api/admin.php?action=stats');
    const data = await res.json();
    if (!data.success) return;

    document.getElementById('adm-total-prod').textContent    = data.total_prod;
    document.getElementById('adm-total-orders').textContent  = data.total_orders;
    document.getElementById('adm-new-orders').textContent    = data.new_orders;
    document.getElementById('adm-total-clients').textContent = data.total_clients;
    document.getElementById('adm-low-stock').textContent     = data.low_stock;
    document.getElementById('adm-blocked').textContent       = data.blocked;

    document.getElementById('lowStockBody').innerHTML = data.low_list.length
      ? data.low_list.map(p => `
          <tr>
            <td><strong>${escHtml(p.nom)}</strong></td>
            <td>${p.categorie}</td>
            <td style="color:${p.quantite == 0 ? 'var(--red)' : 'var(--gold)'};font-weight:700;">${p.quantite == 0 ? 'RUPTURE' : p.quantite}</td>
            <td style="color:var(--muted);">${fmtDH(p.prix_achat)}</td>
            <td>${fmtDH(p.prix_vente)}</td>
            <td><span class="pill ${p.quantite == 0 ? 'pill-red' : 'pill-gold'}">${p.quantite == 0 ? 'Rupture' : 'Stock faible'}</span></td>
          </tr>`).join('')
      : '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:24px;">Aucun produit en stock critique ✓</td></tr>';
  } catch {}
}

/* ── Produits admin ── */
async function renderAdminProducts() {
  const tbody = document.getElementById('adminProdBody');
  if (!tbody) return;
  try {
    const res  = await fetch('api/products.php?action=list');
    const data = await res.json();
    if (!data.success) return;

    const catLabels = { Laptop:'Laptop', Phone:'Smartphone', GPU:'Composant', Console:'Console', Monitor:'Moniteur' };
    tbody.innerHTML = data.products.map(p => `
      <tr>
        <td style="color:var(--muted);font-size:0.75rem;">#${p.id}</td>
        <td><strong>${escHtml(p.nom)}</strong></td>
        <td><span class="pill pill-blue">${catLabels[p.categorie] || p.categorie}</span></td>
        <td style="color:var(--muted);">${fmtDH(p.prix_achat)}</td>
        <td style="color:var(--teal);font-weight:600;">${fmtDH(p.prix_vente)}</td>
        <td style="font-weight:600;">${p.quantite}</td>
        <td><span class="pill ${p.quantite == 0 ? 'pill-red' : p.quantite <= 2 ? 'pill-gold' : 'pill-green'}">${p.quantite == 0 ? 'Rupture' : p.quantite <= 2 ? 'Faible' : 'OK'}</span></td>
        <td>
          <button onclick="openDeleteModal(null,${p.id})"
            style="background:rgba(239,68,68,0.12);color:var(--red);border:1px solid rgba(239,68,68,0.2);padding:5px 12px;border-radius:6px;cursor:pointer;font-size:0.78rem;">
            Supprimer
          </button>
        </td>
      </tr>`).join('');
  } catch {}
}

/* ── Confirmer suppression produit ── */
async function confirmDelete() {
  if (!pendingDeleteId) return;
  const fd = new FormData();
  fd.append('action', 'delete');
  fd.append('id',     pendingDeleteId);

  try {
    const res  = await fetch('api/products.php', { method: 'POST', body: fd });
    const data = await res.json();
    closeModal('deleteModal');
    if (data.success) {
      toast('Produit supprimé', 'info');
      renderProducts();
      renderAdminProducts();
      renderAdminDashboard();
    } else {
      toast(data.error, 'error');
    }
  } catch { toast('Erreur réseau', 'error'); }
}

/* ── Ajouter produit ── */
function previewImg() {
  const file = document.getElementById('addImg').files[0];
  const prev = document.getElementById('imgPreview');
  if (file) {
    const r = new FileReader();
    r.onload = e => { prev.src = e.target.result; prev.style.display = 'block'; };
    r.readAsDataURL(file);
  }
}

async function adminAddProduct() {
  const nom       = document.getElementById('addName').value.trim();
  const prix_vente= document.getElementById('addSellPrice').value;

  if (!nom || !prix_vente) { toast('Nom et prix de vente obligatoires', 'error'); return; }

  const fd = new FormData();
  fd.append('action',      'add');
  fd.append('nom',         nom);
  fd.append('categorie',   document.getElementById('addCat').value);
  fd.append('prix_achat',  document.getElementById('addBuyPrice').value  || 0);
  fd.append('prix_vente',  prix_vente);
  fd.append('quantite',    document.getElementById('addQty').value       || 0);
  fd.append('specs',       document.getElementById('addSpecs').value.trim());
  fd.append('description', document.getElementById('addDesc').value.trim());
  fd.append('image_url',   document.getElementById('addImgUrl').value.trim());

  const imgFile = document.getElementById('addImg').files[0];
  if (imgFile) fd.append('image', imgFile);

  try {
    const res  = await fetch('api/products.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (!data.success) { toast(data.error, 'error'); return; }

    toast(data.message);
    // Reset form
    ['addName','addBuyPrice','addSellPrice','addSpecs','addDesc','addImgUrl'].forEach(id => {
      document.getElementById(id).value = '';
    });
    document.getElementById('addQty').value = '1';
    document.getElementById('addImg').value = '';
    document.getElementById('imgPreview').style.display = 'none';

    renderProducts();
    renderAdminProducts();
    renderAdminDashboard();

    // Basculer vers l'onglet Produits
    document.querySelectorAll('.admin-tab').forEach((t, i) => t.classList.toggle('active', i === 1));
    document.querySelectorAll('.admin-content').forEach((c, i) => c.classList.toggle('active', i === 1));
  } catch { toast('Erreur réseau', 'error'); }
}

/* ── Commandes ── */
function switchOrdersTab(tab) {
  ordersTab = tab;
  document.getElementById('stab-new').classList.toggle('active', tab === 'new');
  document.getElementById('stab-old').classList.toggle('active', tab === 'old');
  document.getElementById('section-new-orders').style.display = tab === 'new' ? 'block' : 'none';
  document.getElementById('section-old-orders').style.display = tab === 'old' ? 'block' : 'none';
  renderAdminOrders();
}

async function renderAdminOrders() {
  const filterProd   = document.getElementById('filterOrderProd')?.value   || '';
  const filterStatus = document.getElementById('filterOrderStatus')?.value || '';

  const params = new URLSearchParams({ action: 'list' });
  if (filterProd)   params.set('produit', filterProd);
  if (filterStatus) params.set('statut',  filterStatus);

  try {
    // Charger nouvelles et anciennes ensemble
    const [resNew, resOld] = await Promise.all([
      fetch('api/orders.php?' + params + '&type=new'),
      fetch('api/orders.php?' + params + '&type=old'),
    ]);
    const dNew = await resNew.json();
    const dOld = await resOld.json();

    // Compteurs
    document.getElementById('cnt-new').textContent = dNew.cnt_new ?? 0;
    document.getElementById('cnt-old').textContent = dOld.cnt_old ?? 0;

    // Nouvelles commandes
    document.getElementById('bodyNewOrders').innerHTML = (dNew.commandes || []).length
      ? dNew.commandes.map(o => `
          <tr class="new-order-row">
            <td style="color:var(--muted);font-size:0.75rem;"><span class="dot-new"></span>#${String(o.id).slice(-5)}</td>
            <td><strong>${escHtml(o.prenom + ' ' + o.nom)}</strong><br><span style="color:var(--muted);font-size:0.75rem;">${escHtml(o.email)}</span></td>
            <td style="font-size:0.82rem;">${(o.details || []).map(d => `${escHtml(d.nom_produit)} ×${d.quantite}`).join('<br>')}</td>
            <td style="color:var(--teal);font-weight:700;">${fmtDH(o.total)}</td>
            <td style="color:var(--muted);font-size:0.82rem;">${o.created_at.slice(0,10)}</td>
            <td><span class="pill ${o.statut === 'validée' ? 'pill-green' : 'pill-red'}">${o.statut}</span></td>
            <td><button class="btn-traiter" onclick="marquerTraitee(${o.id})"><i class="fas fa-check" style="margin-right:4px;"></i>Traiter</button></td>
          </tr>`).join('')
      : '<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:32px;"><i class="fas fa-check-circle" style="color:var(--green);font-size:1.4rem;display:block;margin-bottom:8px;"></i>Aucune nouvelle commande en attente ✓</td></tr>';

    // Anciennes commandes
    document.getElementById('bodyOldOrders').innerHTML = (dOld.commandes || []).length
      ? dOld.commandes.map(o => `
          <tr>
            <td style="color:var(--muted);font-size:0.75rem;">#${String(o.id).slice(-5)}</td>
            <td><strong>${escHtml(o.prenom + ' ' + o.nom)}</strong><br><span style="color:var(--muted);font-size:0.75rem;">${escHtml(o.email)}</span></td>
            <td style="font-size:0.82rem;">${(o.details || []).map(d => `${escHtml(d.nom_produit)} ×${d.quantite}`).join('<br>')}</td>
            <td style="color:var(--teal);font-weight:700;">${fmtDH(o.total)}</td>
            <td style="color:var(--muted);font-size:0.82rem;">${o.created_at.slice(0,10)}</td>
            <td><span class="pill pill-gray">Traitée</span></td>
          </tr>`).join('')
      : '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:24px;">Aucune ancienne commande</td></tr>';

  } catch {}
}

async function marquerTraitee(id) {
  const fd = new FormData();
  fd.append('action', 'mark_done');
  fd.append('id',     id);
  const res  = await fetch('api/orders.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    toast(data.message);
    renderAdminOrders();
    renderAdminDashboard();
  }
}

async function toutTraiter() {
  const fd = new FormData();
  fd.append('action', 'mark_all_done');
  const res  = await fetch('api/orders.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    toast(data.message);
    renderAdminOrders();
    renderAdminDashboard();
  }
}

async function loadProductFilterOptions() {
  const sel = document.getElementById('filterOrderProd');
  if (!sel) return;
  try {
    const res  = await fetch('api/admin.php?action=products_list');
    const data = await res.json();
    if (!data.success) return;
    sel.innerHTML = '<option value="">Tous les produits</option>' +
      data.products.map(p => `<option value="${p.id}">${escHtml(p.nom)}</option>`).join('');
  } catch {}
}

/* ── Clients admin ── */
async function renderAdminClients() {
  const filtre = document.getElementById('filterClientStatut')?.value || '';
  const tbody  = document.getElementById('adminClientsBody');
  if (!tbody) return;
  try {
    const res  = await fetch(`api/admin.php?action=clients&filtre=${encodeURIComponent(filtre)}`);
    const data = await res.json();
    if (!data.success) return;

    tbody.innerHTML = data.clients.length
      ? data.clients.map(c => `
          <tr style="${c.bloque ? 'opacity:0.65;' : ''}">
            <td>
              <strong>${escHtml(c.prenom + ' ' + c.nom)}</strong>
              ${c.bloque ? '<span class="pill pill-orange" style="margin-left:6px;font-size:0.65rem;">Bloqué</span>' : ''}
            </td>
            <td style="color:var(--muted);">${escHtml(c.email)}</td>
            <td>${escHtml(c.telephone || '—')}</td>
            <td>${escHtml(c.ville     || '—')}</td>
            <td>${c.nb_commandes}</td>
            <td>${c.bloque
              ? '<span class="pill pill-orange">Bloqué</span>'
              : '<span class="pill pill-green">Actif</span>'}</td>
            <td>
              <div class="client-actions">
                ${c.bloque
                  ? `<button class="btn-debloquer"   onclick="debloquerClient(${c.id})"><i class="fas fa-unlock"></i> Débloquer</button>`
                  : `<button class="btn-bloquer"     onclick="ouvrirBloquer(${c.id},'${escHtml(c.prenom + ' ' + c.nom)}')"><i class="fas fa-ban"></i> Bloquer</button>`}
                <button class="btn-suppr-client" onclick="ouvrirSupprimerClient(${c.id},'${escHtml(c.prenom + ' ' + c.nom)}')">
                  <i class="fas fa-trash"></i> Supprimer
                </button>
              </div>
            </td>
          </tr>`).join('')
      : '<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:24px;">Aucun client inscrit</td></tr>';
  } catch {}
}

function ouvrirBloquer(id, nom) {
  pendingClientId = id;
  document.getElementById('blockModalTxt').textContent =
    `Le client "${nom}" ne pourra plus se connecter ni passer commande. Vous pourrez le débloquer à tout moment.`;
  document.getElementById('blockModal').classList.add('open');
}

async function confirmBloquer() {
  const fd = new FormData();
  fd.append('action', 'block');
  fd.append('id',     pendingClientId);
  const res  = await fetch('api/admin.php', { method: 'POST', body: fd });
  const data = await res.json();
  closeModal('blockModal');
  if (data.success) { toast('Client bloqué', 'warn'); renderAdminClients(); renderAdminDashboard(); }
  else toast(data.error, 'error');
}

async function debloquerClient(id) {
  const fd = new FormData();
  fd.append('action', 'unblock');
  fd.append('id',     id);
  const res  = await fetch('api/admin.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { toast('Client débloqué ✓'); renderAdminClients(); renderAdminDashboard(); }
  else toast(data.error, 'error');
}

function ouvrirSupprimerClient(id, nom) {
  pendingClientId = id;
  document.getElementById('deleteClientTxt').textContent =
    `Toutes les données du client "${nom}" seront supprimées définitivement. Cette action est irréversible.`;
  document.getElementById('deleteClientModal').classList.add('open');
}

async function confirmSupprimerClient() {
  const fd = new FormData();
  fd.append('action', 'delete_client');
  fd.append('id',     pendingClientId);
  const res  = await fetch('api/admin.php', { method: 'POST', body: fd });
  const data = await res.json();
  closeModal('deleteClientModal');
  if (data.success) { toast('Client supprimé', 'info'); renderAdminClients(); renderAdminDashboard(); }
  else toast(data.error, 'error');
}

/* ════════════════════════════════════════════
   CONTACT
════════════════════════════════════════════ */
function sendContact() {
  const name    = document.getElementById('ctxName').value.trim();
  const email   = document.getElementById('ctxEmail').value.trim();
  const msg     = document.getElementById('ctxMsg').value.trim();
  const subject = document.getElementById('ctxSubject').value;

  if (!name || !email || !msg) { toast('Veuillez remplir tous les champs', 'error'); return; }

  window.open(
    `mailto:admin@marocpc.ma?subject=${encodeURIComponent('[Maroc PC] ' + subject)}&body=${encodeURIComponent('De : ' + name + ' (' + email + ')\n\n' + msg)}`
  );
  toast('Email préparé dans votre messagerie ✓');
}

/* ════════════════════════════════════════════
   UTILITAIRES
════════════════════════════════════════════ */
function fmtDH(n) {
  return Number(n).toLocaleString('fr-MA') + ' DH';
}

function marge(achat, vente) {
  if (!achat || !vente) return '—';
  return Math.round((vente - achat) / vente * 100);
}

function escHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
