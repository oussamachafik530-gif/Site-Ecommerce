# Maroc PC — Guide d'installation

## Structure du projet

```
marocpc/
├── config/
│   └── database.php       ← Connexion PDO + helpers session
├── api/
│   ├── auth.php           ← Login / Inscription / Logout
│   ├── products.php       ← Produits (liste, détail, ajout, suppression)
│   ├── orders.php         ← Commandes (valider, lister, traiter)
│   └── admin.php          ← Stats, gestion clients
├── includes/
│   ├── header.php         ← Navbar + <head>
│   └── footer.php         ← Modals + scripts
├── assets/
│   ├── css/style.css      ← Tous les styles
│   ├── js/app.js          ← Toute la logique JavaScript
│   └── images/
│       ├── no-image.svg   ← Image par défaut
│       └── products/      ← Images uploadées
├── index.php              ← Point d'entrée principal
└── database.sql           ← Schéma + données de démo
```

## Prérequis
- PHP 8.0 ou supérieur
- MySQL 5.7 ou supérieur
- Serveur Apache ou Nginx (XAMPP / WAMP / Laragon recommandé)

## Installation étape par étape

### 1. Installer XAMPP
Télécharger sur https://www.apachefriends.org/ et installer.

### 2. Copier le projet
Copier le dossier `marocpc/` dans `C:/xampp/htdocs/`

### 3. Créer la base de données
- Ouvrir XAMPP Control Panel → Démarrer Apache + MySQL
- Aller sur http://localhost/phpmyadmin
- Cliquer "Nouveau" → nommer la base `marocpc` → Créer
- Cliquer sur la base `marocpc` → onglet "Importer"
- Choisir le fichier `database.sql` → Exécuter

### 4. Configurer la connexion
Ouvrir `config/database.php` et modifier si besoin :
```php
define('DB_USER', 'root');  // votre utilisateur MySQL
define('DB_PASS', '');      // votre mot de passe MySQL
```

### 5. Lancer le site
Ouvrir http://localhost/marocpc/

## Comptes de test

| Rôle          | Email               | Mot de passe |
|---------------|---------------------|--------------|
| Administrateur| admin@marocpc.ma    | admin1234    |
| Client        | (créer un compte)   | (votre choix)|

## Fonctionnalités
- Catalogue produits avec filtres par catégorie
- Fiche détail produit cliquable
- Panier avec calcul automatique
- Inscription / Connexion / Déconnexion
- Validation de commande avec vérification stock
- Panel admin : dashboard, produits, commandes, clients
- Bloquer / Débloquer / Supprimer des clients
- Ajouter / Supprimer des produits avec upload image
- Commandes nouvelles / anciennes avec marquage traité
