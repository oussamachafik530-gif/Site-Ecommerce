-- =============================================
--  marocpc — database.sql
--  Importer : mysql -u root -p marocpc < database.sql
-- =============================================

CREATE DATABASE IF NOT EXISTS marocpc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE marocpc;

-- ── Administrateur ────────────────────────────
CREATE TABLE IF NOT EXISTS administrateur (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nom        VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Matériel ─────────────────────────────────
CREATE TABLE IF NOT EXISTS materiel (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(200) NOT NULL,
    categorie   ENUM('Laptop','Phone','GPU','Console','Monitor') DEFAULT 'Laptop',
    prix_achat  DECIMAL(10,2) NOT NULL DEFAULT 0,
    prix_vente  DECIMAL(10,2) NOT NULL DEFAULT 0,
    quantite    INT NOT NULL DEFAULT 0,
    specs       TEXT,
    description TEXT,
    image       VARCHAR(500) DEFAULT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Client ────────────────────────────────────
CREATE TABLE IF NOT EXISTS client (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    prenom     VARCHAR(100) NOT NULL,
    nom        VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    telephone  VARCHAR(30),
    ville      VARCHAR(100),
    password   VARCHAR(255) NOT NULL,
    bloque     TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Commande client ───────────────────────────
CREATE TABLE IF NOT EXISTS commande_client (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    client_id   INT NOT NULL,
    sous_total  DECIMAL(10,2) NOT NULL DEFAULT 0,
    livraison   DECIMAL(10,2) NOT NULL DEFAULT 0,
    total       DECIMAL(10,2) NOT NULL DEFAULT 0,
    statut      ENUM('validée','rupture','annulée') NOT NULL DEFAULT 'validée',
    traitee     TINYINT(1) NOT NULL DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES client(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Détail commande ───────────────────────────
CREATE TABLE IF NOT EXISTS commande_detail (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    commande_id   INT NOT NULL,
    materiel_id   INT NOT NULL,
    nom_produit   VARCHAR(200) NOT NULL,
    prix_unitaire DECIMAL(10,2) NOT NULL,
    quantite      INT NOT NULL DEFAULT 1,
    total_ligne   DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (commande_id) REFERENCES commande_client(id) ON DELETE CASCADE,
    FOREIGN KEY (materiel_id) REFERENCES materiel(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ══════════════════════════════════════════════
--  DONNÉES DE DÉMO
-- ══════════════════════════════════════════════

-- Admin (password: admin1234)
INSERT INTO administrateur (nom, email, password) VALUES
('Administrateur', 'admin@marocpc.ma', '$2y$10$TKh8H1.PfYdDcFPan89tXuqV6JzGHBHiMlNxHqNtWLbJSsb3fHmKO');

-- Produits
INSERT INTO materiel (nom, categorie, prix_achat, prix_vente, quantite, specs, description, image) VALUES
('PlayStation 5 Pro',       'Console', 7000,  8500,  5, '4K 120fps, SSD 1TB, DualSense',                'La dernière console de Sony avec des performances inégalées.',                'https://gmedia.playstation.com/is/image/SIEPDC/ps5-product-thumbnail-01-en-14sep21?$facebook$'),
('ASUS ROG Strix G16',      'Laptop',  11000, 14500, 3, 'i9-13980HX, RTX 4070, 32GB, 1TB NVMe',        'Laptop gaming ultime pour les performances maximales.',                       'https://dlcdnwebimgs.asus.com/gain/9F88BA73-1B9E-4F8E-B9EF-9EA618C0A2A3/w717/h525'),
('Samsung Galaxy S24 Ultra','Phone',   8500,  11000, 8, 'Snapdragon 8 Gen 3, 12GB RAM, 200MP',          'Smartphone flagship avec stylet intégré et caméra révolutionnaire.',         'https://images.samsung.com/is/image/samsung/p6pim/levant/sm-s928bzkcmea/gallery/levant-galaxy-s24-ultra-s928-sm-s928bzkcmea-536858985?$730_730_PNG$'),
('RTX 4090 Founders Ed.',   'GPU',     14000, 17500, 2, '16384 CUDA Cores, 24GB GDDR6X, 450W TDP',     'La carte graphique la plus puissante de NVIDIA pour la génération actuelle.',  'https://www.nvidia.com/content/dam/en-zz/Solutions/geforce/ada/rtx-4090/geforce-ada-4090-og-1200x630.jpg'),
('LG UltraWide 34" WQHD',  'Monitor', 4500,  6200,  6, '34", 3440x1440, 165Hz, 1ms, HDR600',           'Expérience immersive cinématographique avec taux de rafraîchissement gaming.',  'https://www.lg.com/us/images/monitors/md08003696/gallery/LG-34GP950G-B-D-01.jpg'),
('iPhone 15 Pro Max',       'Phone',   12000, 15500, 4, 'A17 Pro, 48MP, ProRes Video, USB-C, Titanium', 'Le flagship d Apple avec puce A17 Pro et châssis en titane.',                 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-15-pro-finish-select-202309-6-7inch-naturaltitanium?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1692845702708'),
('Xbox Series X',           'Console', 4200,  5800,  1, 'Zen 2 8c, RDNA 2 12 TFLOPS, 1TB NVMe, 8K',   'La console Microsoft pour jouer à vos titres favoris en 4K.',                 'https://news.xbox.com/en-us/wp-content/uploads/sites/2/2020/03/XboxSeriesX_FrontSide.jpg');
