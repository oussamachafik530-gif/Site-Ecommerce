<?php
// =============================================
//  api/admin.php
//  Actions : stats | clients | block | unblock | delete_client
// =============================================
require_once __DIR__ . '/../config/database.php';
requireAdmin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── Statistiques dashboard ────────────────
    case 'stats':
        $pdo = getDB();

        $totalProd    = $pdo->query("SELECT COUNT(*) FROM materiel")->fetchColumn();
        $totalOrders  = $pdo->query("SELECT COUNT(*) FROM commande_client")->fetchColumn();
        $newOrders    = $pdo->query("SELECT COUNT(*) FROM commande_client WHERE traitee = 0")->fetchColumn();
        $totalClients = $pdo->query("SELECT COUNT(*) FROM client")->fetchColumn();
        $lowStock     = $pdo->query("SELECT COUNT(*) FROM materiel WHERE quantite <= 2")->fetchColumn();
        $blocked      = $pdo->query("SELECT COUNT(*) FROM client WHERE bloque = 1")->fetchColumn();

        // Produits stock critique
        $stmtLow = $pdo->query("SELECT * FROM materiel WHERE quantite <= 2 ORDER BY quantite ASC");
        $lowList = $stmtLow->fetchAll();

        jsonResponse([
            'success'       => true,
            'total_prod'    => (int)$totalProd,
            'total_orders'  => (int)$totalOrders,
            'new_orders'    => (int)$newOrders,
            'total_clients' => (int)$totalClients,
            'low_stock'     => (int)$lowStock,
            'blocked'       => (int)$blocked,
            'low_list'      => $lowList,
        ]);
        break;

    // ── Liste clients ─────────────────────────
    case 'clients':
        $pdo    = getDB();
        $filtre = $_GET['filtre'] ?? ''; // 'actif' | 'bloqué' | ''

        $sql    = "SELECT c.*,
                   (SELECT COUNT(*) FROM commande_client WHERE client_id = c.id) AS nb_commandes
                   FROM client c WHERE 1=1";
        $params = [];

        if ($filtre === 'actif')   { $sql .= " AND c.bloque = 0"; }
        if ($filtre === 'bloqué')  { $sql .= " AND c.bloque = 1"; }

        $sql .= " ORDER BY c.created_at DESC";
        $stmt  = $pdo->prepare($sql);
        $stmt->execute($params);
        $clients = $stmt->fetchAll();

        // Ne jamais exposer le hash du mot de passe
        foreach ($clients as &$cl) unset($cl['password']);

        jsonResponse(['success' => true, 'clients' => $clients]);
        break;

    // ── Bloquer un client ─────────────────────
    case 'block':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID manquant.'], 400);

        $pdo  = getDB();
        $stmt = $pdo->prepare("UPDATE client SET bloque = 1 WHERE id = ?");
        $stmt->execute([$id]);

        jsonResponse(['success' => true, 'message' => 'Client bloqué avec succès.']);
        break;

    // ── Débloquer un client ───────────────────
    case 'unblock':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID manquant.'], 400);

        $pdo  = getDB();
        $stmt = $pdo->prepare("UPDATE client SET bloque = 0 WHERE id = ?");
        $stmt->execute([$id]);

        jsonResponse(['success' => true, 'message' => 'Client débloqué avec succès ✓']);
        break;

    // ── Supprimer un client ───────────────────
    case 'delete_client':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID manquant.'], 400);

        $pdo  = getDB();
        $stmt = $pdo->prepare("DELETE FROM client WHERE id = ?");
        $stmt->execute([$id]);

        jsonResponse(['success' => true, 'message' => 'Client supprimé définitivement.']);
        break;

    // ── Liste des produits pour filtre commande
    case 'products_list':
        $pdo  = getDB();
        $stmt = $pdo->query("SELECT id, nom FROM materiel ORDER BY nom ASC");
        jsonResponse(['success' => true, 'products' => $stmt->fetchAll()]);
        break;

    default:
        jsonResponse(['success' => false, 'error' => 'Action inconnue.'], 400);
}
