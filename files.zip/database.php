<?php
// =============================================
//  config/database.php
//  Connexion PDO + helpers session
// =============================================

define('DB_HOST',    'localhost');
define('DB_NAME',    'marocpc');
define('DB_USER',    'root');     // ← modifier
define('DB_PASS',    '');         // ← modifier
define('DB_CHARSET', 'utf8mb4');

// ── Connexion PDO (singleton) ─────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'error' => 'Erreur BDD : ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ── Session ───────────────────────────────────
if (session_status() === PHP_SESSION_NONE) session_start();

function isAdmin():  bool { return ($_SESSION['role'] ?? '') === 'admin';  }
function isClient(): bool { return ($_SESSION['role'] ?? '') === 'client'; }
function isLogged(): bool { return isset($_SESSION['user_id']); }

// ── Sécurité ──────────────────────────────────
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function requireLogin(): void {
    if (!isLogged()) jsonResponse(['success' => false, 'error' => 'Non connecté'], 401);
}

function requireAdmin(): void {
    if (!isAdmin()) jsonResponse(['success' => false, 'error' => 'ACCÈS NON AUTORISÉ'], 403);
}
