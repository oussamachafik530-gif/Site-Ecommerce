<?php
// =============================================
//  api/orders.php
//  Actions : validate | list | mark_done | mark_all_done
// =============================================
require_once __DIR__ . '/../config/database.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── Valider une commande ──────────────────
    case 'validate':
        requireLogin();
        if (!isClient()) jsonResponse(['success' => false, 'error' => 'Réservé aux clients.'], 403);

        $pdo = getDB();

        // Vérifier si le client est bloqué
        $stmt = $pdo->prepare("SELECT bloque FROM client WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $c = $stmt->fetch();
        if ($c && $c['bloque']) {
            jsonResponse(['success' => false, 'error' => 'Votre compte est suspendu. Impossible de commander.']);
        }

        // Récupérer le panier envoyé (JSON)
        $cartJson = $_POST['cart'] ?? '';
        $cart     = json_decode($cartJson, true);
        if (!$cart || !is_array($cart)) {
            jsonResponse(['success' => false, 'error' => 'Panier vide ou invalide.']);
        }

        // ── Vérifications stock ───────────────
        $errors = [];
        $items  = [];
        foreach ($cart as $ci) {
            $id  = (int)$ci['id'];
            $qty = (int)$ci['qty'];
            if ($id <= 0 || $qty <= 0) continue;

            $stmt = $pdo->prepare("SELECT * FROM materiel WHERE id = ?");
            $stmt->execute([$id]);
            $prod = $stmt->fetch();

            if (!$prod) {
                $errors[] = "Produit #$id introuvable.";
                continue;
            }
            if ($prod['quantite'] === 0) {
                $errors[] = "{$prod['nom']} : RUPTURE DE STOCK";
                continue;
            }
            if ($qty > $prod['quantite']) {
                $errors[] = "{$prod['nom']} : quantité insuffisante (stock: {$prod['quantite']}, demandé: $qty)";
                continue;
            }

            $items[] = ['prod' => $prod, 'qty' => $qty];
        }

        if ($errors) {
            jsonResponse(['success' => false, 'error' => $errors[0], 'all_errors' => $errors]);
        }

        // ── Calcul total ──────────────────────
        $sous_total = 0;
        foreach ($items as $item) {
            $sous_total += $item['prod']['prix_vente'] * $item['qty'];
        }
        $livraison = $sous_total > 10000 ? 0 : 79;
        $total     = $sous_total + $livraison;

        // ── Insérer commande ──────────────────
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO commande_client (client_id, sous_total, livraison, total, statut, traitee)
                 VALUES (?, ?, ?, ?, 'validée', 0)"
            );
            $stmt->execute([$_SESSION['user_id'], $sous_total, $livraison, $total]);
            $commandeId = $pdo->lastInsertId();

            foreach ($items as $item) {
                $p = $item['prod'];
                $q = $item['qty'];

                // Insérer détail
                $stmt = $pdo->prepare(
                    "INSERT INTO commande_detail (commande_id, materiel_id, nom_produit, prix_unitaire, quantite, total_ligne)
                     VALUES (?,?,?,?,?,?)"
                );
                $stmt->execute([
                    $commandeId,
                    $p['id'],
                    $p['nom'],
                    $p['prix_vente'],
                    $q,
                    $p['prix_vente'] * $q
                ]);

                // Décrémenter stock
                $stmt = $pdo->prepare("UPDATE materiel SET quantite = quantite - ? WHERE id = ?");
                $stmt->execute([$q, $p['id']]);
            }

            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            jsonResponse(['success' => false, 'error' => 'Erreur lors de la commande : ' . $e->getMessage()]);
        }

        // ── Retourner le récapitulatif ────────
        $stmt = $pdo->prepare("SELECT * FROM client WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $client = $stmt->fetch();

        $orderItems = array_map(fn($i) => [
            'nom'       => $i['prod']['nom'],
            'qty'       => $i['qty'],
            'prix'      => $i['prod']['prix_vente'],
            'total'     => $i['prod']['prix_vente'] * $i['qty'],
        ], $items);

        jsonResponse([
            'success'     => true,
            'commande_id' => $commandeId,
            'client_name' => $client['prenom'] . ' ' . $client['nom'],
            'items'       => $orderItems,
            'sous_total'  => $sous_total,
            'livraison'   => $livraison,
            'total'       => $total,
            'date'        => date('d/m/Y'),
        ]);
        break;

    // ── Liste commandes (admin) ───────────────
    case 'list':
        requireAdmin();
        $pdo = getDB();

        $filtreProd   = (int)($_GET['produit']  ?? 0);
        $filtreStatut = $_GET['statut']          ?? '';
        $filtreType   = $_GET['type']            ?? ''; // 'new' | 'old'

        $sql = "SELECT cc.*, c.prenom, c.nom, c.email
                FROM commande_client cc
                JOIN client c ON c.id = cc.client_id
                WHERE 1=1";
        $params = [];

        if ($filtreStatut) { $sql .= " AND cc.statut = ?";  $params[] = $filtreStatut; }
        if ($filtreType === 'new') { $sql .= " AND cc.traitee = 0"; }
        if ($filtreType === 'old') { $sql .= " AND cc.traitee = 1"; }

        $sql .= " ORDER BY cc.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $commandes = $stmt->fetchAll();

        // Récupérer les détails de chaque commande
        foreach ($commandes as &$cmd) {
            $s = $pdo->prepare(
                "SELECT cd.*, m.categorie FROM commande_detail cd
                 LEFT JOIN materiel m ON m.id = cd.materiel_id
                 WHERE cd.commande_id = ?"
            );
            $s->execute([$cmd['id']]);
            $cmd['details'] = $s->fetchAll();

            // Filtre produit
            if ($filtreProd) {
                $hasProduct = false;
                foreach ($cmd['details'] as $d) {
                    if ((int)$d['materiel_id'] === $filtreProd) { $hasProduct = true; break; }
                }
                if (!$hasProduct) { $cmd = null; }
            }
        }
        $commandes = array_values(array_filter($commandes));

        // Compteurs
        $stmtNew = $pdo->query("SELECT COUNT(*) FROM commande_client WHERE traitee = 0");
        $stmtOld = $pdo->query("SELECT COUNT(*) FROM commande_client WHERE traitee = 1");

        jsonResponse([
            'success'   => true,
            'commandes' => $commandes,
            'cnt_new'   => (int)$stmtNew->fetchColumn(),
            'cnt_old'   => (int)$stmtOld->fetchColumn(),
        ]);
        break;

    // ── Marquer une commande comme traitée ────
    case 'mark_done':
        requireAdmin();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID manquant.'], 400);

        $pdo  = getDB();
        $stmt = $pdo->prepare("UPDATE commande_client SET traitee = 1 WHERE id = ?");
        $stmt->execute([$id]);

        jsonResponse(['success' => true, 'message' => 'Commande marquée comme traitée ✓']);
        break;

    // ── Tout marquer traité ───────────────────
    case 'mark_all_done':
        requireAdmin();
        $pdo = getDB();
        $pdo->exec("UPDATE commande_client SET traitee = 1 WHERE traitee = 0");
        jsonResponse(['success' => true, 'message' => 'Toutes les commandes marquées comme traitées ✓']);
        break;

    default:
        jsonResponse(['success' => false, 'error' => 'Action inconnue.'], 400);
}
